# Data directory

Run:

```bash
python scripts/download_marketdata.py --with-vxn
```

The generated `daily_adjclose.csv` supports model-based tests. It is not historical option-chain data.

For exact quote mode, place a normalized QQQ option quote file here and follow the schema in `../examples/historical_option_quotes_schema.csv`.
