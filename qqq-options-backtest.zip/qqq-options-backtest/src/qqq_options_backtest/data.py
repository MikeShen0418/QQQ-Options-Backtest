from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from .config import BacktestConfig


DATE_CANDIDATES = ("date", "Date", "timestamp", "Timestamp", "quote_date")


def _first_present(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    column_set = set(columns)
    return next((candidate for candidate in candidates if candidate in column_set), None)


def _to_decimal(series: pd.Series, percent_threshold: float = 2.0) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce").astype(float)
    typical = values.abs().median(skipna=True)
    if pd.notna(typical) and typical > percent_threshold:
        values = values / 100.0
    return values


def load_market_data(path: str | Path, config: BacktestConfig) -> pd.DataFrame:
    """
    Load either the project's normalized schema or a wide adjusted-close file.

    Normalized schema: date, spot, rate, iv (rate and iv as decimals).
    Wide schema: Date, QQQ, ^IRX, ^VIX and optionally ^VXN/VXN/VXNCLS.
    """
    source_path = Path(path)
    if not source_path.exists():
        raise FileNotFoundError(
            f"Market data not found: {source_path}. Run scripts/download_marketdata.py "
            "or provide a CSV with date, spot, rate, and iv columns."
        )

    raw = pd.read_csv(source_path)
    date_column = _first_present(raw.columns, DATE_CANDIDATES)
    if date_column is None:
        raise ValueError("Market data must contain a date-like column")

    raw[date_column] = pd.to_datetime(raw[date_column], errors="coerce", utc=False)
    raw = raw.dropna(subset=[date_column]).sort_values(date_column)
    raw = raw.drop_duplicates(subset=[date_column], keep="last").set_index(date_column)
    raw.index = pd.DatetimeIndex(raw.index).tz_localize(None).normalize()

    spot_column = _first_present(raw.columns, ("spot", "Spot", "QQQ", "qqq", "close", "Close"))
    if spot_column is None:
        raise ValueError("Market data must contain a spot/QQQ/close column")

    market = pd.DataFrame(index=raw.index)
    market["spot"] = pd.to_numeric(raw[spot_column], errors="coerce")

    rate_column = _first_present(raw.columns, ("rate", "Rate", "risk_free_rate", "^IRX", "IRX"))
    if rate_column is None:
        market["rate"] = config.portfolio.default_cash_rate
    elif rate_column in {"^IRX", "IRX"}:
        market["rate"] = pd.to_numeric(raw[rate_column], errors="coerce") / 100.0
    else:
        market["rate"] = _to_decimal(raw[rate_column])

    log_returns = np.log(market["spot"] / market["spot"].shift(1))
    realized = (
        log_returns.rolling(config.model.realized_vol_window, min_periods=5).std()
        * np.sqrt(252.0)
        * config.model.realized_vol_multiplier
    )

    vxn_column = _first_present(raw.columns, ("iv", "IV", "^VXN", "VXN", "VXNCLS"))
    vix_column = _first_present(raw.columns, ("^VIX", "VIX", "vix"))

    if vxn_column is not None:
        direct_iv = _to_decimal(raw[vxn_column])
    else:
        direct_iv = pd.Series(index=raw.index, dtype=float)

    if vix_column is not None:
        vix_scaled = _to_decimal(raw[vix_column]) * config.model.vix_multiplier
    else:
        vix_scaled = pd.Series(index=raw.index, dtype=float)

    mode = config.model.iv_mode.lower()
    if mode == "vxn":
        if vxn_column is None:
            raise ValueError("iv_mode='vxn' requires an iv, ^VXN, VXN, or VXNCLS column")
        iv = direct_iv
    elif mode == "vix_scaled":
        if vix_column is None:
            raise ValueError("iv_mode='vix_scaled' requires a ^VIX, VIX, or vix column")
        iv = vix_scaled
    elif mode == "realized":
        iv = realized
    elif mode == "hybrid":
        components = pd.concat([direct_iv, vix_scaled, realized], axis=1)
        iv = components.max(axis=1, skipna=True)
    else:
        raise ValueError("iv_mode must be one of: vxn, vix_scaled, realized, hybrid")

    market["iv"] = iv
    market["realized_vol"] = realized

    market = market.replace([np.inf, -np.inf], np.nan)
    market["rate"] = market["rate"].ffill(limit=10).fillna(config.portfolio.default_cash_rate)
    market["iv"] = market["iv"].ffill(limit=10).fillna(realized).fillna(config.model.default_iv)
    market["iv"] = market["iv"].clip(config.model.min_iv, config.model.max_iv)
    market = market.dropna(subset=["spot"])
    market = market[market["spot"] > 0]

    end = pd.Timestamp(config.data.end_date) if config.data.end_date else market.index.max()
    start: pd.Timestamp | None
    if config.data.start_date:
        start = pd.Timestamp(config.data.start_date)
    elif config.data.years:
        start = end - pd.DateOffset(years=int(config.data.years))
    else:
        start = None

    if start is not None:
        market = market[market.index >= start]
    market = market[market.index <= end]

    if len(market) < config.strategy.hold_trading_days + 2:
        raise ValueError("Not enough observations after applying the requested date window")

    market.index.name = "date"
    market.attrs["source_path"] = str(source_path)
    market.attrs["iv_mode"] = config.model.iv_mode
    return market


def load_option_quotes(path: str | Path) -> pd.DataFrame:
    """Load normalized historical option quotes for the exact-quote provider."""
    source_path = Path(path)
    if not source_path.exists():
        raise FileNotFoundError(f"Option quotes not found: {source_path}")

    quotes = pd.read_csv(source_path)
    aliases = {
        "date": "quote_date",
        "quote_date": "quote_date",
        "timestamp": "quote_date",
        "expiry": "expiration",
        "expiration": "expiration",
        "expiration_date": "expiration",
        "put_call": "option_type",
        "option_type": "option_type",
        "right": "option_type",
        "strike": "strike",
        "bid": "bid",
        "ask": "ask",
        "mid": "mid",
        "symbol": "symbol",
        "underlying": "underlying",
        "underlying_price": "underlying",
        "delta": "delta",
        "volume": "volume",
        "open_interest": "open_interest",
    }
    quotes = quotes.rename(
        columns={column: aliases.get(column.lower().strip(), column) for column in quotes.columns}
    )

    required = {"quote_date", "expiration", "option_type", "strike"}
    missing = required - set(quotes.columns)
    if missing:
        raise ValueError(f"Option quote CSV is missing columns: {sorted(missing)}")
    if not ({"bid", "ask"} <= set(quotes.columns) or "mid" in quotes.columns):
        raise ValueError("Option quote CSV needs bid+ask or a mid column")

    quotes["quote_date"] = pd.to_datetime(quotes["quote_date"], errors="coerce").dt.tz_localize(None).dt.normalize()
    quotes["expiration"] = pd.to_datetime(quotes["expiration"], errors="coerce").dt.tz_localize(None).dt.normalize()
    quotes["strike"] = pd.to_numeric(quotes["strike"], errors="coerce")
    for column in ("bid", "ask", "mid", "underlying", "delta", "volume", "open_interest"):
        if column in quotes.columns:
            quotes[column] = pd.to_numeric(quotes[column], errors="coerce")

    option_type = quotes["option_type"].astype(str).str.lower().str.strip()
    quotes["option_type"] = option_type.replace({"c": "call", "p": "put", "1": "call", "-1": "put"})
    quotes = quotes.dropna(subset=["quote_date", "expiration", "strike"])
    quotes = quotes[quotes["strike"] > 0]

    if "symbol" not in quotes.columns:
        quotes["symbol"] = (
            quotes["expiration"].dt.strftime("%Y%m%d")
            + "_"
            + quotes["option_type"].str[0].str.upper()
            + "_"
            + quotes["strike"].map(lambda value: f"{value:.3f}")
        )

    if "mid" not in quotes.columns:
        quotes["mid"] = (quotes["bid"] + quotes["ask"]) / 2.0
    if "bid" not in quotes.columns:
        quotes["bid"] = quotes["mid"]
    if "ask" not in quotes.columns:
        quotes["ask"] = quotes["mid"]

    quotes = quotes.sort_values(["quote_date", "expiration", "strike"])
    quotes = quotes.drop_duplicates(["quote_date", "symbol"], keep="last")
    return quotes.reset_index(drop=True)
