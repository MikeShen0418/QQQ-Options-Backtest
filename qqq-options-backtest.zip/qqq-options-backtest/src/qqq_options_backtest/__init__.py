"""QQQ call-roll backtesting package."""

from .config import BacktestConfig, load_config
from .engine import BacktestResult, run_backtest

__all__ = ["BacktestConfig", "BacktestResult", "load_config", "run_backtest"]
__version__ = "0.1.0"
