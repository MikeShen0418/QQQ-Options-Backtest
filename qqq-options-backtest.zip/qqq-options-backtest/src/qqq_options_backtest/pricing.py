from __future__ import annotations

import math



def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def black_scholes_call(
    spot: float,
    strike: float,
    time_years: float,
    rate: float,
    volatility: float,
    dividend_yield: float = 0.0,
) -> float:
    """European call value with continuous rates and dividend yield."""
    if spot <= 0 or strike <= 0:
        raise ValueError("spot and strike must be positive")
    if time_years <= 0:
        return max(spot - strike, 0.0)
    if volatility <= 0:
        forward_pv = spot * math.exp(-dividend_yield * time_years)
        strike_pv = strike * math.exp(-rate * time_years)
        return max(forward_pv - strike_pv, 0.0)

    root_t = math.sqrt(time_years)
    d1 = (
        math.log(spot / strike)
        + (rate - dividend_yield + 0.5 * volatility**2) * time_years
    ) / (volatility * root_t)
    d2 = d1 - volatility * root_t
    return (
        spot * math.exp(-dividend_yield * time_years) * _normal_cdf(d1)
        - strike * math.exp(-rate * time_years) * _normal_cdf(d2)
    )


def rounded_strike(spot: float, moneyness: float, increment: float) -> float:
    target = spot * (1.0 + moneyness)
    return round(target / increment) * increment


def model_half_spread(mid: float, percentage: float, minimum: float) -> float:
    return max(minimum, max(mid, 0.0) * percentage)
