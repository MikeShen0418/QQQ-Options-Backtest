from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass(slots=True)
class PortfolioConfig:
    initial_capital: float = 100_000.0
    allocation_per_entry: float = 0.01
    sleeve_cap: float = 0.05
    option_multiplier: int = 100
    allow_fractional_contracts: bool = True
    earn_cash_interest: bool = True
    default_cash_rate: float = 0.02


@dataclass(slots=True)
class StrategyConfig:
    mode: str = "daily_ladder"  # daily_ladder or weekly_single
    entry_dte_target: int = 28
    entry_dte_min: int = 25
    entry_dte_max: int = 30
    hold_trading_days: int = 5
    moneyness: float = 0.0  # strike = spot * (1 + moneyness)
    strike_increment: float = 1.0
    weekly_entry_weekday: int = 4  # Monday=0, Friday=4


@dataclass(slots=True)
class ModelConfig:
    pricing_method: str = "black_scholes"
    iv_mode: str = "vix_scaled"  # vxn, vix_scaled, realized, hybrid
    vix_multiplier: float = 1.15
    realized_vol_window: int = 20
    realized_vol_multiplier: float = 1.10
    min_iv: float = 0.08
    max_iv: float = 1.50
    dividend_yield: float = 0.0
    default_iv: float = 0.25


@dataclass(slots=True)
class ExecutionConfig:
    model_half_spread_pct: float = 0.025
    model_min_half_spread: float = 0.01
    commission_per_contract: float = 0.65
    minimum_option_price: float = 0.01


@dataclass(slots=True)
class RiskConfig:
    wipeout_threshold: float = -0.90
    loss_threshold: float = 0.0


@dataclass(slots=True)
class DataConfig:
    market_data_path: str = "data/daily_adjclose.csv"
    option_quotes_path: str | None = None
    quote_mode: str = "model"  # model or historical
    start_date: str | None = None
    end_date: str | None = None
    years: int | None = 20


@dataclass(slots=True)
class BacktestConfig:
    portfolio: PortfolioConfig = field(default_factory=PortfolioConfig)
    strategy: StrategyConfig = field(default_factory=StrategyConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    execution: ExecutionConfig = field(default_factory=ExecutionConfig)
    risk: RiskConfig = field(default_factory=RiskConfig)
    data: DataConfig = field(default_factory=DataConfig)

    def validate(self) -> None:
        if self.strategy.mode not in {"daily_ladder", "weekly_single"}:
            raise ValueError("strategy.mode must be 'daily_ladder' or 'weekly_single'")
        if self.data.quote_mode not in {"model", "historical"}:
            raise ValueError("data.quote_mode must be 'model' or 'historical'")
        if not 0 < self.portfolio.allocation_per_entry <= 1:
            raise ValueError("allocation_per_entry must be in (0, 1]")
        if not 0 < self.portfolio.sleeve_cap <= 1:
            raise ValueError("sleeve_cap must be in (0, 1]")
        if self.portfolio.allocation_per_entry > self.portfolio.sleeve_cap:
            raise ValueError("allocation_per_entry cannot exceed sleeve_cap")
        if not (
            self.strategy.entry_dte_min
            <= self.strategy.entry_dte_target
            <= self.strategy.entry_dte_max
        ):
            raise ValueError("entry_dte_target must be inside [entry_dte_min, entry_dte_max]")
        if self.strategy.hold_trading_days < 1:
            raise ValueError("hold_trading_days must be positive")
        if self.strategy.strike_increment <= 0:
            raise ValueError("strike_increment must be positive")
        if self.portfolio.initial_capital <= 0:
            raise ValueError("initial_capital must be positive")
        if self.execution.commission_per_contract < 0:
            raise ValueError("commission_per_contract cannot be negative")
        if not -1 < self.risk.wipeout_threshold < 0:
            raise ValueError("wipeout_threshold should be a return between -1 and 0")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _construct(config_dict: dict[str, Any]) -> BacktestConfig:
    return BacktestConfig(
        portfolio=PortfolioConfig(**config_dict.get("portfolio", {})),
        strategy=StrategyConfig(**config_dict.get("strategy", {})),
        model=ModelConfig(**config_dict.get("model", {})),
        execution=ExecutionConfig(**config_dict.get("execution", {})),
        risk=RiskConfig(**config_dict.get("risk", {})),
        data=DataConfig(**config_dict.get("data", {})),
    )


def load_config(path: str | Path) -> BacktestConfig:
    with Path(path).open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    config = _construct(raw)
    config.validate()
    return config
