from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .engine import BacktestResult


PERCENT_KEYS = {
    "total_return",
    "cagr",
    "annualized_volatility",
    "max_drawdown",
    "best_day",
    "worst_day",
    "win_rate",
    "average_trade_return",
    "median_trade_return",
    "best_trade_return",
    "worst_trade_return",
    "wipeout_threshold",
    "wipeout_rate",
    "return_on_premium_deployed",
    "max_reserved_pct_equity",
    "qqq_buy_hold_total_return",
    "qqq_buy_hold_cagr",
    "qqq_buy_hold_max_drawdown",
    "average_underlying_return_during_hold",
    "average_entry_allocation",
}

MONEY_KEYS = {
    "initial_equity",
    "final_equity",
    "cash_interest_earned",
    "total_option_pnl",
    "total_premium_deployed",
    "total_commissions",
}


def _json_safe(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, dict):
        return {key: _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def _display_value(key: str, value: Any) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, (float, np.floating)) and not np.isfinite(value):
        return "n/a"
    if key in PERCENT_KEYS and isinstance(value, (int, float, np.number)):
        return f"{float(value):,.2%}"
    if key in MONEY_KEYS and isinstance(value, (int, float, np.number)):
        return f"${float(value):,.2f}"
    if isinstance(value, (float, np.floating)):
        return f"{float(value):,.4f}"
    return str(value)




def _streak_table(trades: pd.DataFrame, flag_column: str) -> pd.DataFrame:
    columns = ["streak_number", "start_exit_date", "end_exit_date", "length", "trade_ids"]
    if trades.empty or flag_column not in trades.columns:
        return pd.DataFrame(columns=columns)
    ordered = trades.sort_values(["exit_date", "trade_id"]).reset_index(drop=True)
    records = []
    start = None
    trade_ids: list[int] = []
    streak_number = 0
    for _, row in ordered.iterrows():
        if bool(row[flag_column]):
            if start is None:
                start = pd.Timestamp(row["exit_date"])
            trade_ids.append(int(row["trade_id"]))
            end = pd.Timestamp(row["exit_date"])
        elif start is not None:
            streak_number += 1
            records.append(
                {
                    "streak_number": streak_number,
                    "start_exit_date": start,
                    "end_exit_date": end,
                    "length": len(trade_ids),
                    "trade_ids": ",".join(map(str, trade_ids)),
                }
            )
            start = None
            trade_ids = []
    if start is not None:
        streak_number += 1
        records.append(
            {
                "streak_number": streak_number,
                "start_exit_date": start,
                "end_exit_date": end,
                "length": len(trade_ids),
                "trade_ids": ",".join(map(str, trade_ids)),
            }
        )
    return pd.DataFrame(records, columns=columns)


def _save_charts(result: BacktestResult, output_dir: Path) -> None:
    curve = result.equity_curve
    initial = result.config.portfolio.initial_capital
    benchmark = curve["spot"] / curve["spot"].iloc[0] * initial

    figure = plt.figure(figsize=(11, 6))
    axis = figure.add_subplot(111)
    axis.plot(curve.index, curve["equity"], label="Strategy portfolio")
    axis.plot(curve.index, benchmark, label="QQQ buy-and-hold benchmark")
    axis.set_title("Portfolio Equity")
    axis.set_xlabel("Date")
    axis.set_ylabel("Equity")
    axis.legend()
    axis.grid(True, alpha=0.25)
    figure.tight_layout()
    figure.savefig(output_dir / "equity_curve.png", dpi=150)
    plt.close(figure)

    drawdown = curve["equity"] / curve["equity"].cummax() - 1.0
    figure = plt.figure(figsize=(11, 4.5))
    axis = figure.add_subplot(111)
    axis.fill_between(drawdown.index, drawdown.values, 0.0, alpha=0.5)
    axis.set_title("Strategy Drawdown")
    axis.set_xlabel("Date")
    axis.set_ylabel("Drawdown")
    axis.grid(True, alpha=0.25)
    figure.tight_layout()
    figure.savefig(output_dir / "drawdown.png", dpi=150)
    plt.close(figure)

    if not result.trades.empty:
        figure = plt.figure(figsize=(9, 5))
        axis = figure.add_subplot(111)
        axis.hist(result.trades["trade_return"].clip(-1.0, 4.0), bins=50)
        axis.axvline(result.config.risk.wipeout_threshold, linestyle="--", label="Wipeout threshold")
        axis.set_title("One-Week Option Trade Returns")
        axis.set_xlabel("Net premium return")
        axis.set_ylabel("Count")
        axis.legend()
        axis.grid(True, alpha=0.25)
        figure.tight_layout()
        figure.savefig(output_dir / "trade_return_histogram.png", dpi=150)
        plt.close(figure)


def write_report(result: BacktestResult, output_dir: str | Path) -> Path:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    result.equity_curve.to_csv(output / "equity_curve.csv")
    result.trades.to_csv(output / "trades.csv", index=False)
    _streak_table(result.trades, "is_wipeout").to_csv(output / "wipeout_streaks.csv", index=False)
    _streak_table(result.trades, "is_loss").to_csv(output / "loss_streaks.csv", index=False)

    payload = {
        "summary": _json_safe(result.summary),
        "diagnostics": _json_safe(result.diagnostics),
        "config": _json_safe(result.config.to_dict()),
    }
    with (output / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, allow_nan=False)
    pd.DataFrame([_json_safe(result.summary)]).to_csv(output / "summary.csv", index=False)
    _save_charts(result, output)

    rows = "\n".join(
        f"<tr><th>{html.escape(key.replace('_', ' ').title())}</th>"
        f"<td>{html.escape(_display_value(key, value))}</td></tr>"
        for key, value in result.summary.items()
    )
    config_json = html.escape(json.dumps(_json_safe(result.config.to_dict()), indent=2))
    diagnostics_json = html.escape(json.dumps(_json_safe(result.diagnostics), indent=2))
    market_source = str(result.diagnostics.get("market_data_source") or "")
    if "demo_synthetic" in market_source.lower():
        caveat = (
            "SYNTHETIC VALIDATION DATA — NOT A HISTORICAL INVESTMENT RESULT. "
            "This report only verifies that the software runs end to end."
        )
    elif result.config.data.quote_mode == "model":
        caveat = (
            "MODEL-BASED APPROXIMATION: option marks are generated by Black-Scholes from the selected "
            "volatility proxy. They are not historical QQQ option quotes."
        )
    else:
        caveat = (
            "HISTORICAL-QUOTE MODE: results depend on the completeness and quality of the supplied quote file."
        )

    document = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>QQQ Call Roll Backtest</title>
<style>
body {{ font-family: Arial, sans-serif; max-width: 1100px; margin: 32px auto; padding: 0 20px; line-height: 1.45; color: #202124; }}
h1, h2 {{ margin-bottom: 0.35rem; }}
.notice {{ padding: 12px 14px; background: #fff4ce; border: 1px solid #e4c766; border-radius: 6px; }}
table {{ border-collapse: collapse; width: 100%; margin: 16px 0 28px; }}
th, td {{ border-bottom: 1px solid #ddd; padding: 8px 10px; text-align: left; }}
th {{ width: 48%; }}
img {{ max-width: 100%; border: 1px solid #ddd; margin: 8px 0 20px; }}
pre {{ background: #f5f5f5; padding: 14px; overflow: auto; }}
.small {{ color: #5f6368; font-size: 0.92rem; }}
</style>
</head>
<body>
<h1>QQQ 25-30 DTE Call Roll Backtest</h1>
<p class="notice"><strong>{html.escape(caveat)}</strong></p>
<p>Each lot risks approximately {result.config.portfolio.allocation_per_entry:.1%} of current portfolio equity, with no more than {result.config.portfolio.sleeve_cap:.1%} of entry premium reserved across active lots. Each option is held for {result.config.strategy.hold_trading_days} trading sessions.</p>
<h2>Results</h2>
<table>{rows}</table>
<h2>Equity</h2>
<img src="equity_curve.png" alt="Equity curve">
<h2>Drawdown</h2>
<img src="drawdown.png" alt="Drawdown">
<h2>Trade distribution</h2>
<img src="trade_return_histogram.png" alt="Trade return histogram">
<h2>Diagnostics</h2>
<pre>{diagnostics_json}</pre>
<h2>Configuration</h2>
<pre>{config_json}</pre>
<p class="small">A “wipeout” is a single option lot with a net premium return at or below {result.config.risk.wipeout_threshold:.0%}; it does not mean the entire portfolio went to zero.</p>
</body>
</html>"""
    report_path = output / "report.html"
    report_path.write_text(document, encoding="utf-8")
    return report_path
