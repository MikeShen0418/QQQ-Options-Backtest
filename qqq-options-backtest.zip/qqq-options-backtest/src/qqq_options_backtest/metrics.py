from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .config import BacktestConfig


def _longest_true_streak(values: pd.Series) -> int:
    longest = 0
    current = 0
    for value in values.fillna(False).astype(bool):
        if value:
            current += 1
            longest = max(longest, current)
        else:
            current = 0
    return longest


def _count_streak_episodes(values: pd.Series, minimum_length: int = 2) -> int:
    count = 0
    current = 0
    for value in values.fillna(False).astype(bool):
        if value:
            current += 1
        elif current:
            count += int(current >= minimum_length)
            current = 0
    if current:
        count += int(current >= minimum_length)
    return count


def _max_drawdown_details(
    equity: pd.Series, initial_value: float | None = None
) -> tuple[float, pd.Timestamp | None, pd.Timestamp | None]:
    if equity.empty:
        return np.nan, None, None
    running_peak = equity.cummax()
    if initial_value is not None:
        running_peak = running_peak.clip(lower=float(initial_value))
    drawdown = equity / running_peak - 1.0
    trough_date = drawdown.idxmin()
    max_drawdown = float(drawdown.loc[trough_date])
    prior = equity.loc[:trough_date]
    if initial_value is not None and prior.max() < initial_value:
        peak_date = equity.index[0]
    else:
        peak_date = prior.idxmax()
    return max_drawdown, pd.Timestamp(peak_date), pd.Timestamp(trough_date)


def calculate_summary(
    equity_curve: pd.DataFrame,
    trades: pd.DataFrame,
    config: BacktestConfig,
) -> dict[str, Any]:
    equity = equity_curve["equity"].astype(float)
    first = float(config.portfolio.initial_capital)
    last = float(equity.iloc[-1])
    daily_returns = equity.pct_change()
    daily_returns.iloc[0] = equity.iloc[0] / first - 1.0
    daily_returns = daily_returns.dropna()
    elapsed_years = max((equity.index[-1] - equity.index[0]).days / 365.25, 1 / 365.25)
    total_return = last / first - 1.0
    cagr = (last / first) ** (1.0 / elapsed_years) - 1.0 if first > 0 and last > 0 else np.nan
    annualized_vol = float(daily_returns.std(ddof=1) * np.sqrt(252.0)) if len(daily_returns) > 1 else np.nan
    sharpe = (
        float(daily_returns.mean() / daily_returns.std(ddof=1) * np.sqrt(252.0))
        if len(daily_returns) > 1 and daily_returns.std(ddof=1) > 0
        else np.nan
    )
    max_drawdown, peak_date, trough_date = _max_drawdown_details(equity, initial_value=first)
    calmar = cagr / abs(max_drawdown) if max_drawdown < 0 and np.isfinite(cagr) else np.nan

    underlying = equity_curve["spot"].astype(float)
    underlying_total_return = underlying.iloc[-1] / underlying.iloc[0] - 1.0
    underlying_cagr = (
        (underlying.iloc[-1] / underlying.iloc[0]) ** (1.0 / elapsed_years) - 1.0
        if underlying.iloc[0] > 0
        else np.nan
    )
    underlying_mdd, _, _ = _max_drawdown_details(underlying)

    summary: dict[str, Any] = {
        "start_date": equity.index[0].date().isoformat(),
        "end_date": equity.index[-1].date().isoformat(),
        "calendar_years": elapsed_years,
        "initial_equity": first,
        "final_equity": last,
        "total_return": total_return,
        "cagr": cagr,
        "annualized_volatility": annualized_vol,
        "sharpe_zero_rf": sharpe,
        "max_drawdown": max_drawdown,
        "max_drawdown_peak_date": peak_date.date().isoformat() if peak_date else None,
        "max_drawdown_trough_date": trough_date.date().isoformat() if trough_date else None,
        "calmar_ratio": calmar,
        "best_day": float(daily_returns.max()) if not daily_returns.empty else np.nan,
        "worst_day": float(daily_returns.min()) if not daily_returns.empty else np.nan,
        "max_simultaneous_positions": int(equity_curve["active_positions"].max()),
        "max_reserved_pct_equity": float(equity_curve["reserved_pct_equity"].max()),
        "cash_interest_earned": float(equity_curve["cumulative_cash_interest"].iloc[-1]),
        "qqq_buy_hold_total_return": float(underlying_total_return),
        "qqq_buy_hold_cagr": float(underlying_cagr),
        "qqq_buy_hold_max_drawdown": float(underlying_mdd),
    }

    if trades.empty:
        summary.update(
            {
                "trade_count": 0,
                "win_rate": np.nan,
                "average_trade_return": np.nan,
                "median_trade_return": np.nan,
                "best_trade_return": np.nan,
                "worst_trade_return": np.nan,
                "max_consecutive_losses": 0,
                "wipeout_threshold": config.risk.wipeout_threshold,
                "wipeout_trade_count": 0,
                "wipeout_rate": np.nan,
                "max_consecutive_wipeouts": 0,
                "wipeout_streak_episodes_2plus": 0,
                "total_option_pnl": 0.0,
                "total_premium_deployed": 0.0,
                "return_on_premium_deployed": np.nan,
                "total_commissions": 0.0,
            }
        )
        return summary

    ordered = trades.sort_values(["exit_date", "trade_id"]).reset_index(drop=True)
    returns = ordered["trade_return"].astype(float)
    losses = returns < config.risk.loss_threshold
    wipeouts = returns <= config.risk.wipeout_threshold
    total_premium = float(ordered["entry_cost"].sum())
    total_pnl = float(ordered["pnl"].sum())
    gains = ordered.loc[ordered["pnl"] > 0, "pnl"].sum()
    losses_dollars = -ordered.loc[ordered["pnl"] < 0, "pnl"].sum()

    summary.update(
        {
            "trade_count": int(len(ordered)),
            "win_rate": float((returns > 0).mean()),
            "average_trade_return": float(returns.mean()),
            "median_trade_return": float(returns.median()),
            "best_trade_return": float(returns.max()),
            "worst_trade_return": float(returns.min()),
            "average_underlying_return_during_hold": float(ordered["underlying_return"].mean()),
            "max_consecutive_losses": _longest_true_streak(losses),
            "wipeout_threshold": config.risk.wipeout_threshold,
            "wipeout_trade_count": int(wipeouts.sum()),
            "wipeout_rate": float(wipeouts.mean()),
            "max_consecutive_wipeouts": _longest_true_streak(wipeouts),
            "wipeout_streak_episodes_2plus": _count_streak_episodes(wipeouts, minimum_length=2),
            "total_option_pnl": total_pnl,
            "total_premium_deployed": total_premium,
            "return_on_premium_deployed": total_pnl / total_premium if total_premium else np.nan,
            "premium_turnover_vs_initial_capital": total_premium / config.portfolio.initial_capital,
            "total_commissions": float(ordered["total_commission"].sum()),
            "profit_factor": float(gains / losses_dollars) if losses_dollars > 0 else np.inf,
            "average_entry_allocation": float(ordered["entry_allocation"].mean()),
        }
    )
    return summary
