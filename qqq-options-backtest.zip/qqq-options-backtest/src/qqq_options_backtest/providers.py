from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np
import pandas as pd

from .config import BacktestConfig
from .pricing import black_scholes_call, model_half_spread, rounded_strike


@dataclass(frozen=True, slots=True)
class OptionContract:
    symbol: str
    expiration: pd.Timestamp
    strike: float
    option_type: str = "call"


@dataclass(frozen=True, slots=True)
class OpenQuote:
    contract: OptionContract
    price: float
    model_mid: float
    source: str


class OptionPricingProvider(Protocol):
    source_name: str

    def open_contract(
        self, date: pd.Timestamp, spot: float, iv: float, rate: float
    ) -> OpenQuote | None: ...

    def mark_price(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float | None: ...

    def exit_price(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float | None: ...


class BlackScholesProvider:
    source_name = "black_scholes_proxy"

    def __init__(self, config: BacktestConfig):
        self.config = config

    def _mid(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float:
        time_years = max((contract.expiration - date).days, 0) / 365.25
        return black_scholes_call(
            spot=spot,
            strike=contract.strike,
            time_years=time_years,
            rate=rate,
            volatility=iv,
            dividend_yield=self.config.model.dividend_yield,
        )

    def open_contract(
        self, date: pd.Timestamp, spot: float, iv: float, rate: float
    ) -> OpenQuote:
        expiration = date + pd.Timedelta(days=self.config.strategy.entry_dte_target)
        strike = rounded_strike(
            spot,
            self.config.strategy.moneyness,
            self.config.strategy.strike_increment,
        )
        contract = OptionContract(
            symbol=f"MODEL_{expiration:%Y%m%d}_C_{strike:.3f}",
            expiration=expiration,
            strike=strike,
        )
        mid = self._mid(date, contract, spot, iv, rate)
        half_spread = model_half_spread(
            mid,
            self.config.execution.model_half_spread_pct,
            self.config.execution.model_min_half_spread,
        )
        entry = max(mid + half_spread, self.config.execution.minimum_option_price)
        return OpenQuote(contract=contract, price=entry, model_mid=mid, source=self.source_name)

    def mark_price(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float:
        return max(self._mid(date, contract, spot, iv, rate), 0.0)

    def exit_price(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float:
        mid = self._mid(date, contract, spot, iv, rate)
        half_spread = model_half_spread(
            mid,
            self.config.execution.model_half_spread_pct,
            self.config.execution.model_min_half_spread,
        )
        return max(mid - half_spread, 0.0)


class HistoricalQuoteProvider:
    source_name = "historical_quotes"

    def __init__(self, quotes: pd.DataFrame, config: BacktestConfig, max_stale_days: int = 3):
        self.quotes = quotes.copy()
        self.config = config
        self.max_stale_days = max_stale_days
        self._by_date = {date: frame for date, frame in self.quotes.groupby("quote_date", sort=False)}
        self._by_symbol = {
            symbol: frame.sort_values("quote_date")
            for symbol, frame in self.quotes.groupby("symbol", sort=False)
        }

    @staticmethod
    def _valid_price(value: object) -> float | None:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return None
        return number if np.isfinite(number) and number >= 0 else None

    def open_contract(
        self, date: pd.Timestamp, spot: float, iv: float, rate: float
    ) -> OpenQuote | None:
        chain = self._by_date.get(date)
        if chain is None or chain.empty:
            return None

        chain = chain[chain["option_type"] == "call"].copy()
        chain["dte"] = (chain["expiration"] - date).dt.days
        chain = chain[
            chain["dte"].between(
                self.config.strategy.entry_dte_min,
                self.config.strategy.entry_dte_max,
                inclusive="both",
            )
        ]
        if chain.empty:
            return None

        chain["dte_distance"] = (chain["dte"] - self.config.strategy.entry_dte_target).abs()
        best_expiration = (
            chain.groupby("expiration", as_index=False)["dte_distance"]
            .min()
            .sort_values(["dte_distance", "expiration"])
            .iloc[0]["expiration"]
        )
        chain = chain[chain["expiration"] == best_expiration].copy()
        target_strike = spot * (1.0 + self.config.strategy.moneyness)
        chain["strike_distance"] = (chain["strike"] - target_strike).abs()
        row = chain.sort_values(["strike_distance", "strike"]).iloc[0]

        ask = self._valid_price(row.get("ask"))
        mid = self._valid_price(row.get("mid"))
        if ask is None:
            ask = mid
        if ask is None or ask <= 0:
            return None
        if mid is None:
            mid = ask

        contract = OptionContract(
            symbol=str(row["symbol"]),
            expiration=pd.Timestamp(row["expiration"]),
            strike=float(row["strike"]),
        )
        return OpenQuote(contract=contract, price=ask, model_mid=mid, source=self.source_name)

    def _find_quote(self, date: pd.Timestamp, contract: OptionContract) -> pd.Series | None:
        history = self._by_symbol.get(contract.symbol)
        if history is None or history.empty:
            return None
        candidates = history[history["quote_date"] <= date]
        if candidates.empty:
            return None
        row = candidates.iloc[-1]
        age = (date - pd.Timestamp(row["quote_date"])).days
        if age > self.max_stale_days:
            return None
        return row

    def mark_price(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float | None:
        row = self._find_quote(date, contract)
        return None if row is None else self._valid_price(row.get("mid"))

    def exit_price(
        self,
        date: pd.Timestamp,
        contract: OptionContract,
        spot: float,
        iv: float,
        rate: float,
    ) -> float | None:
        row = self._find_quote(date, contract)
        if row is None:
            return None
        bid = self._valid_price(row.get("bid"))
        if bid is not None:
            return bid
        return self._valid_price(row.get("mid"))
