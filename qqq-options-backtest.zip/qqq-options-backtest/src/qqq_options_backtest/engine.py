from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from .config import BacktestConfig
from .providers import OpenQuote, OptionContract, OptionPricingProvider


@dataclass(slots=True)
class Position:
    trade_id: int
    entry_index: int
    exit_index: int
    entry_date: pd.Timestamp
    planned_exit_date: pd.Timestamp
    contract: OptionContract
    units: float
    entry_price: float
    entry_mid: float
    entry_total_cost: float
    entry_commission: float
    entry_spot: float
    entry_iv: float
    entry_rate: float
    entry_equity: float
    source: str
    last_mark_price: float


@dataclass(slots=True)
class BacktestResult:
    config: BacktestConfig
    equity_curve: pd.DataFrame
    trades: pd.DataFrame
    summary: dict[str, Any]
    diagnostics: dict[str, Any] = field(default_factory=dict)


def _weekly_entry_dates(index: pd.DatetimeIndex, target_weekday: int) -> set[pd.Timestamp]:
    dates: set[pd.Timestamp] = set()
    frame = pd.DataFrame(index=index)
    frame["week"] = frame.index.to_period("W-SUN")
    for _, group in frame.groupby("week", sort=True):
        period = group["week"].iloc[0]
        target = period.start_time + pd.Timedelta(days=target_weekday)
        before_or_on = group.index[group.index <= target]
        chosen = before_or_on.max() if len(before_or_on) else group.index.min()
        dates.add(pd.Timestamp(chosen))
    return dates


def _should_enter(
    date: pd.Timestamp,
    index_number: int,
    final_index: int,
    config: BacktestConfig,
    weekly_dates: set[pd.Timestamp],
) -> bool:
    if index_number + config.strategy.hold_trading_days > final_index:
        return False
    if config.strategy.mode == "daily_ladder":
        return True
    return date in weekly_dates


def _position_mark_value(
    position: Position,
    date: pd.Timestamp,
    row: pd.Series,
    provider: OptionPricingProvider,
    multiplier: int,
) -> tuple[float, float, bool]:
    mark = provider.mark_price(
        date,
        position.contract,
        float(row["spot"]),
        float(row["iv"]),
        float(row["rate"]),
    )
    used_fallback = False
    if mark is None or not np.isfinite(mark):
        mark = position.last_mark_price
        used_fallback = True
    mark = max(float(mark), 0.0)
    position.last_mark_price = mark
    return position.units * multiplier * mark, mark, used_fallback


def run_backtest(
    market: pd.DataFrame,
    provider: OptionPricingProvider,
    config: BacktestConfig,
) -> BacktestResult:
    config.validate()
    required = {"spot", "iv", "rate"}
    missing = required - set(market.columns)
    if missing:
        raise ValueError(f"Market frame is missing columns: {sorted(missing)}")
    if not isinstance(market.index, pd.DatetimeIndex):
        raise TypeError("Market frame index must be a DatetimeIndex")

    market = market.sort_index().copy()
    index = market.index
    weekly_dates = _weekly_entry_dates(index, config.strategy.weekly_entry_weekday)

    cash = float(config.portfolio.initial_capital)
    cumulative_cash_interest = 0.0
    positions: list[Position] = []
    trade_rows: list[dict[str, Any]] = []
    curve_rows: list[dict[str, Any]] = []
    skipped_entries: dict[str, int] = {
        "provider_no_contract": 0,
        "sleeve_or_cash_limit": 0,
        "whole_contract_rounding": 0,
    }
    mark_fallback_count = 0
    exit_fallback_count = 0
    next_trade_id = 1
    previous_date: pd.Timestamp | None = None
    previous_rate = config.portfolio.default_cash_rate

    for i, (date, row) in enumerate(market.iterrows()):
        date = pd.Timestamp(date)
        spot = float(row["spot"])
        iv = float(row["iv"])
        rate = float(row["rate"])

        if previous_date is not None and config.portfolio.earn_cash_interest and cash > 0:
            elapsed_days = max((date - previous_date).days, 0)
            interest = cash * previous_rate * elapsed_days / 365.25
            cash += interest
            cumulative_cash_interest += interest

        # Exit at the current close before opening the day's replacement lot.
        remaining: list[Position] = []
        for position in positions:
            if i < position.exit_index:
                remaining.append(position)
                continue

            exit_price = provider.exit_price(date, position.contract, spot, iv, rate)
            exit_method = "provider_exit"
            if exit_price is None or not np.isfinite(exit_price):
                exit_price = provider.mark_price(date, position.contract, spot, iv, rate)
                exit_method = "provider_mark_fallback"
            if exit_price is None or not np.isfinite(exit_price):
                exit_price = position.last_mark_price
                exit_method = "last_mark_fallback"
            if exit_method != "provider_exit":
                exit_fallback_count += 1

            exit_price = max(float(exit_price), 0.0)
            gross_proceeds = position.units * config.portfolio.option_multiplier * exit_price
            exit_commission = (
                position.units * config.execution.commission_per_contract
                if exit_price > 0
                else 0.0
            )
            net_proceeds = max(gross_proceeds - exit_commission, 0.0)
            cash += net_proceeds
            pnl = net_proceeds - position.entry_total_cost
            trade_return = pnl / position.entry_total_cost if position.entry_total_cost else np.nan

            trade_rows.append(
                {
                    "trade_id": position.trade_id,
                    "entry_date": position.entry_date,
                    "exit_date": date,
                    "planned_exit_date": position.planned_exit_date,
                    "symbol": position.contract.symbol,
                    "expiration": position.contract.expiration,
                    "strike": position.contract.strike,
                    "entry_dte": (position.contract.expiration - position.entry_date).days,
                    "exit_dte": (position.contract.expiration - date).days,
                    "hold_trading_days": i - position.entry_index,
                    "units": position.units,
                    "entry_spot": position.entry_spot,
                    "exit_spot": spot,
                    "underlying_return": spot / position.entry_spot - 1.0,
                    "entry_iv": position.entry_iv,
                    "exit_iv": iv,
                    "entry_price": position.entry_price,
                    "entry_mid": position.entry_mid,
                    "exit_price": exit_price,
                    "entry_cost": position.entry_total_cost,
                    "gross_exit_proceeds": gross_proceeds,
                    "net_exit_proceeds": net_proceeds,
                    "entry_commission": position.entry_commission,
                    "exit_commission": exit_commission,
                    "total_commission": position.entry_commission + exit_commission,
                    "pnl": pnl,
                    "trade_return": trade_return,
                    "entry_equity": position.entry_equity,
                    "entry_allocation": position.entry_total_cost / position.entry_equity,
                    "pricing_source": position.source,
                    "exit_method": exit_method,
                }
            )
        positions = remaining

        # Mark positions before the new entry to size against current equity.
        marked_options_value = 0.0
        for position in positions:
            value, _, fallback = _position_mark_value(
                position,
                date,
                row,
                provider,
                config.portfolio.option_multiplier,
            )
            marked_options_value += value
            mark_fallback_count += int(fallback)
        equity_before_entry = cash + marked_options_value

        if _should_enter(date, i, len(index) - 1, config, weekly_dates):
            open_quote: OpenQuote | None = provider.open_contract(date, spot, iv, rate)
            if open_quote is None:
                skipped_entries["provider_no_contract"] += 1
            else:
                active_reserved_premium = sum(position.entry_total_cost for position in positions)
                sleeve_limit = config.portfolio.sleeve_cap * equity_before_entry
                available_sleeve = max(sleeve_limit - active_reserved_premium, 0.0)
                desired_budget = config.portfolio.allocation_per_entry * equity_before_entry
                budget = min(desired_budget, available_sleeve, cash)

                per_contract_total = (
                    open_quote.price * config.portfolio.option_multiplier
                    + config.execution.commission_per_contract
                )
                if budget <= 0 or per_contract_total <= 0:
                    skipped_entries["sleeve_or_cash_limit"] += 1
                else:
                    raw_units = budget / per_contract_total
                    units = (
                        raw_units
                        if config.portfolio.allow_fractional_contracts
                        else float(np.floor(raw_units))
                    )
                    if units <= 0:
                        skipped_entries["whole_contract_rounding"] += 1
                    else:
                        entry_commission = units * config.execution.commission_per_contract
                        entry_total_cost = (
                            units * config.portfolio.option_multiplier * open_quote.price
                            + entry_commission
                        )
                        # Numerical guard: fractional sizing can exceed cash by a few cents.
                        if entry_total_cost > cash:
                            units *= cash / entry_total_cost
                            entry_commission = units * config.execution.commission_per_contract
                            entry_total_cost = (
                                units * config.portfolio.option_multiplier * open_quote.price
                                + entry_commission
                            )
                        cash -= entry_total_cost
                        exit_index = i + config.strategy.hold_trading_days
                        planned_exit_date = pd.Timestamp(index[exit_index])
                        positions.append(
                            Position(
                                trade_id=next_trade_id,
                                entry_index=i,
                                exit_index=exit_index,
                                entry_date=date,
                                planned_exit_date=planned_exit_date,
                                contract=open_quote.contract,
                                units=units,
                                entry_price=open_quote.price,
                                entry_mid=open_quote.model_mid,
                                entry_total_cost=entry_total_cost,
                                entry_commission=entry_commission,
                                entry_spot=spot,
                                entry_iv=iv,
                                entry_rate=rate,
                                entry_equity=equity_before_entry,
                                source=open_quote.source,
                                last_mark_price=open_quote.model_mid,
                            )
                        )
                        next_trade_id += 1

        # End-of-day mark after any new trade.
        options_value = 0.0
        for position in positions:
            value, _, fallback = _position_mark_value(
                position,
                date,
                row,
                provider,
                config.portfolio.option_multiplier,
            )
            options_value += value
            mark_fallback_count += int(fallback)

        equity = cash + options_value
        active_reserved = sum(position.entry_total_cost for position in positions)
        curve_rows.append(
            {
                "date": date,
                "spot": spot,
                "iv": iv,
                "rate": rate,
                "cash": cash,
                "options_value": options_value,
                "equity": equity,
                "active_positions": len(positions),
                "reserved_entry_premium": active_reserved,
                "reserved_pct_equity": active_reserved / equity if equity > 0 else np.nan,
                "cumulative_cash_interest": cumulative_cash_interest,
            }
        )

        previous_date = date
        previous_rate = rate

    if positions:
        raise RuntimeError("Backtest ended with unclosed positions; entry-window guard failed")

    equity_curve = pd.DataFrame(curve_rows).set_index("date")
    trades = pd.DataFrame(trade_rows)
    if not trades.empty:
        trades["is_wipeout"] = trades["trade_return"] <= config.risk.wipeout_threshold
        trades["is_loss"] = trades["trade_return"] < config.risk.loss_threshold

    from .metrics import calculate_summary

    summary = calculate_summary(equity_curve, trades, config)
    diagnostics = {
        "skipped_entries": skipped_entries,
        "mark_fallback_count": mark_fallback_count,
        "exit_fallback_count": exit_fallback_count,
        "pricing_source": provider.source_name,
        "requested_mode": config.strategy.mode,
        "market_data_source": market.attrs.get("source_path"),
        "market_iv_mode": market.attrs.get("iv_mode", config.model.iv_mode),
        "market_rows": len(market),
    }
    return BacktestResult(
        config=config,
        equity_curve=equity_curve,
        trades=trades,
        summary=summary,
        diagnostics=diagnostics,
    )
