from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_config
from .data import load_market_data, load_option_quotes
from .engine import run_backtest
from .providers import BlackScholesProvider, HistoricalQuoteProvider
from .report import write_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="qqq-backtest",
        description="Backtest rolling 25-30 DTE QQQ call options held for one trading week.",
    )
    parser.add_argument("--config", default="config/default.yaml")
    parser.add_argument("--market-data", help="Override market_data_path from the YAML file")
    parser.add_argument("--option-quotes", help="Normalized historical option quote CSV")
    parser.add_argument("--quote-mode", choices=["model", "historical"])
    parser.add_argument("--mode", choices=["daily_ladder", "weekly_single"])
    parser.add_argument("--years", type=int, choices=[10, 20])
    parser.add_argument("--start-date")
    parser.add_argument("--end-date")
    parser.add_argument("--moneyness", type=float, help="0.00=ATM, 0.02=2%% OTM")
    parser.add_argument("--whole-contracts", action="store_true")
    parser.add_argument("--output", default="outputs/run")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    config = load_config(args.config)

    if args.market_data:
        config.data.market_data_path = args.market_data
    if args.option_quotes:
        config.data.option_quotes_path = args.option_quotes
    if args.quote_mode:
        config.data.quote_mode = args.quote_mode
    if args.mode:
        config.strategy.mode = args.mode
    if args.years:
        config.data.years = args.years
        config.data.start_date = None
    if args.start_date:
        config.data.start_date = args.start_date
        config.data.years = None
    if args.end_date:
        config.data.end_date = args.end_date
    if args.moneyness is not None:
        config.strategy.moneyness = args.moneyness
    if args.whole_contracts:
        config.portfolio.allow_fractional_contracts = False
    config.validate()

    market = load_market_data(config.data.market_data_path, config)
    if config.data.quote_mode == "historical":
        if not config.data.option_quotes_path:
            raise SystemExit("historical quote mode requires --option-quotes or data.option_quotes_path")
        quotes = load_option_quotes(config.data.option_quotes_path)
        provider = HistoricalQuoteProvider(quotes, config)
    else:
        provider = BlackScholesProvider(config)

    result = run_backtest(market, provider, config)
    report_path = write_report(result, args.output)
    print(json.dumps(result.summary, indent=2, default=str))
    print(f"\nReport: {report_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
