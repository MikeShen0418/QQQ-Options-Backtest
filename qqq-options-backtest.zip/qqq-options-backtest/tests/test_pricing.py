import pytest

from qqq_options_backtest.pricing import black_scholes_call, rounded_strike


def test_black_scholes_reference_value():
    price = black_scholes_call(100.0, 100.0, 1.0, 0.05, 0.20, 0.0)
    assert price == pytest.approx(10.4506, rel=1e-4)


def test_call_intrinsic_at_expiry():
    assert black_scholes_call(110.0, 100.0, 0.0, 0.05, 0.20) == 10.0
    assert black_scholes_call(90.0, 100.0, 0.0, 0.05, 0.20) == 0.0


def test_rounded_strike():
    assert rounded_strike(401.2, 0.0, 1.0) == 401.0
    assert rounded_strike(401.2, 0.02, 5.0) == 410.0
