import copy

import numpy as np
import pandas as pd

from qqq_options_backtest.config import BacktestConfig
from qqq_options_backtest.engine import run_backtest
from qqq_options_backtest.providers import BlackScholesProvider


def make_market(periods: int = 80) -> pd.DataFrame:
    dates = pd.bdate_range("2024-01-02", periods=periods)
    spot = 400.0 * np.exp(np.linspace(0.0, 0.08, periods))
    return pd.DataFrame(
        {"spot": spot, "iv": 0.24, "rate": 0.04},
        index=dates,
    )


def test_daily_ladder_has_five_or_fewer_positions():
    config = BacktestConfig()
    config.portfolio.earn_cash_interest = False
    config.strategy.mode = "daily_ladder"
    market = make_market()
    result = run_backtest(market, BlackScholesProvider(config), config)
    assert result.summary["trade_count"] == len(market) - config.strategy.hold_trading_days
    assert result.summary["max_simultaneous_positions"] <= 5
    assert result.equity_curve["reserved_pct_equity"].max() < 0.052
    assert not result.trades.empty
    assert result.equity_curve["equity"].notna().all()


def test_weekly_single_enters_less_often():
    daily_config = BacktestConfig()
    daily_config.portfolio.earn_cash_interest = False
    weekly_config = copy.deepcopy(daily_config)
    weekly_config.strategy.mode = "weekly_single"
    market = make_market()
    daily = run_backtest(market, BlackScholesProvider(daily_config), daily_config)
    weekly = run_backtest(market, BlackScholesProvider(weekly_config), weekly_config)
    assert weekly.summary["trade_count"] < daily.summary["trade_count"]
    assert weekly.summary["max_simultaneous_positions"] <= 1


def test_total_return_uses_original_initial_capital():
    config = BacktestConfig()
    config.portfolio.earn_cash_interest = False
    market = make_market(30)
    result = run_backtest(market, BlackScholesProvider(config), config)
    expected = result.equity_curve["equity"].iloc[-1] / config.portfolio.initial_capital - 1.0
    assert result.summary["total_return"] == expected
