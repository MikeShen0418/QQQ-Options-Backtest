from pathlib import Path

import pandas as pd
import pytest

from qqq_options_backtest.config import BacktestConfig
from qqq_options_backtest.data import load_market_data, load_option_quotes


def test_load_wide_market_data(tmp_path: Path):
    dates = pd.bdate_range("2024-01-01", periods=40)
    frame = pd.DataFrame(
        {
            "Date": dates,
            "QQQ": range(400, 440),
            "^IRX": [5.0] * 40,
            "^VIX": [20.0] * 40,
        }
    )
    path = tmp_path / "market.csv"
    frame.to_csv(path, index=False)
    config = BacktestConfig()
    config.data.years = None
    market = load_market_data(path, config)
    assert list(market.columns) == ["spot", "rate", "iv", "realized_vol"]
    assert market["rate"].iloc[0] == 0.05
    assert market["iv"].iloc[0] == pytest.approx(0.23)


def test_load_option_quotes(tmp_path: Path):
    path = tmp_path / "quotes.csv"
    pd.DataFrame(
        {
            "quote_date": ["2025-01-02"],
            "expiration": ["2025-01-31"],
            "option_type": ["C"],
            "strike": [500],
            "bid": [8.0],
            "ask": [8.2],
        }
    ).to_csv(path, index=False)
    quotes = load_option_quotes(path)
    assert quotes.loc[0, "option_type"] == "call"
    assert quotes.loc[0, "mid"] == 8.1
