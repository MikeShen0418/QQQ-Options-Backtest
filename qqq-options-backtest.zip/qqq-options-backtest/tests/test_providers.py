import pandas as pd
import pytest

from qqq_options_backtest.config import BacktestConfig
from qqq_options_backtest.data import load_option_quotes
from qqq_options_backtest.providers import HistoricalQuoteProvider


def test_historical_provider_selects_target_dte_and_nearest_strike(tmp_path):
    entry = pd.Timestamp("2025-01-02")
    exit_date = pd.Timestamp("2025-01-09")
    rows = []
    for expiration in (pd.Timestamp("2025-01-27"), pd.Timestamp("2025-01-31")):
        for strike in (99.0, 100.0, 101.0):
            symbol = f"{expiration:%Y%m%d}_C_{strike:.0f}"
            rows.append(
                {
                    "quote_date": entry,
                    "expiration": expiration,
                    "option_type": "call",
                    "strike": strike,
                    "bid": 4.8,
                    "ask": 5.0 + abs(strike - 100.0),
                    "symbol": symbol,
                }
            )
            rows.append(
                {
                    "quote_date": exit_date,
                    "expiration": expiration,
                    "option_type": "call",
                    "strike": strike,
                    "bid": 5.5,
                    "ask": 5.7,
                    "symbol": symbol,
                }
            )
    path = tmp_path / "quotes.csv"
    pd.DataFrame(rows).to_csv(path, index=False)
    quotes = load_option_quotes(path)
    config = BacktestConfig()
    provider = HistoricalQuoteProvider(quotes, config)

    opened = provider.open_contract(entry, spot=100.2, iv=0.2, rate=0.04)
    assert opened is not None
    assert opened.contract.expiration == pd.Timestamp("2025-01-31")
    assert opened.contract.strike == 100.0
    assert opened.price == pytest.approx(5.0)
    assert provider.exit_price(exit_date, opened.contract, 102.0, 0.2, 0.04) == pytest.approx(5.5)
