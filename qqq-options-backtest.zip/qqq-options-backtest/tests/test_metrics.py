import pandas as pd

from qqq_options_backtest.metrics import _count_streak_episodes, _longest_true_streak


def test_streak_helpers():
    values = pd.Series([False, True, True, False, True, True, True, False, True])
    assert _longest_true_streak(values) == 3
    assert _count_streak_episodes(values, minimum_length=2) == 2
