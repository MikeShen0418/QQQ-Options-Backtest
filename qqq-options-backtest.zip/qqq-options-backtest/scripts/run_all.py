#!/usr/bin/env python3
"""Run both strategy interpretations over 10-year and 20-year windows."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import pandas as pd

from qqq_options_backtest.config import load_config
from qqq_options_backtest.data import load_market_data, load_option_quotes
from qqq_options_backtest.engine import run_backtest
from qqq_options_backtest.providers import BlackScholesProvider, HistoricalQuoteProvider
from qqq_options_backtest.report import write_report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default.yaml")
    parser.add_argument("--market-data")
    parser.add_argument("--option-quotes")
    parser.add_argument("--quote-mode", choices=["model", "historical"])
    parser.add_argument("--output-root", default="outputs")
    args = parser.parse_args()

    base = load_config(args.config)
    if args.market_data:
        base.data.market_data_path = args.market_data
    if args.option_quotes:
        base.data.option_quotes_path = args.option_quotes
    if args.quote_mode:
        base.data.quote_mode = args.quote_mode

    comparison_rows = []
    for years in (10, 20):
        for mode in ("daily_ladder", "weekly_single"):
            config = copy.deepcopy(base)
            config.data.years = years
            config.data.start_date = None
            config.strategy.mode = mode
            config.validate()
            market = load_market_data(config.data.market_data_path, config)
            if config.data.quote_mode == "historical":
                if not config.data.option_quotes_path:
                    raise SystemExit("Historical mode requires --option-quotes")
                provider = HistoricalQuoteProvider(load_option_quotes(config.data.option_quotes_path), config)
            else:
                provider = BlackScholesProvider(config)
            result = run_backtest(market, provider, config)
            output = Path(args.output_root) / f"{years}y_{mode}_{config.data.quote_mode}"
            report = write_report(result, output)
            comparison_rows.append(
                {"years": years, "mode": mode, "quote_mode": config.data.quote_mode, **result.summary}
            )
            print(f"{years}y {mode}: {result.summary['cagr']:.2%} CAGR, "
                  f"{result.summary['max_drawdown']:.2%} max DD -> {report}")

    root = Path(args.output_root)
    root.mkdir(parents=True, exist_ok=True)
    comparison = pd.DataFrame(comparison_rows)
    comparison.to_csv(root / "comparison_summary.csv", index=False)
    with (root / "comparison_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(comparison_rows, handle, indent=2, default=str)
    print(f"Comparison table: {root / 'comparison_summary.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
