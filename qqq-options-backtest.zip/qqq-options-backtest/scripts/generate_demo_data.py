#!/usr/bin/env python3
"""Generate deterministic synthetic data for validating the project plumbing only."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/demo_synthetic_market.csv")
    parser.add_argument("--start", default="2004-01-02")
    parser.add_argument("--end", default="2026-08-11")
    parser.add_argument("--seed", type=int, default=731)
    args = parser.parse_args()

    dates = pd.bdate_range(args.start, args.end)
    rng = np.random.default_rng(args.seed)

    regime_vol = np.full(len(dates), 0.22)
    regime_vol[(dates >= "2008-09-01") & (dates <= "2009-04-30")] = 0.55
    regime_vol[(dates >= "2020-02-20") & (dates <= "2020-05-15")] = 0.70
    regime_vol[(dates >= "2022-01-01") & (dates <= "2022-11-30")] = 0.34
    annual_drift = 0.105
    shocks = rng.normal(0.0, 1.0, len(dates))
    daily_returns = annual_drift / 252.0 + regime_vol / np.sqrt(252.0) * shocks
    qqq = 35.0 * np.exp(np.cumsum(daily_returns))

    noise = rng.normal(0.0, 1.2, len(dates))
    vix = np.clip(regime_vol * 100.0 * 0.88 + noise, 9.0, 85.0)
    years = (dates - dates[0]).days / 365.25
    irx = np.clip(2.2 + 1.8 * np.sin(years / 2.4) + rng.normal(0, 0.12, len(dates)), 0.02, 5.5)

    frame = pd.DataFrame({"Date": dates, "QQQ": qqq, "^IRX": irx, "^VIX": vix})
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    print(f"Saved synthetic validation data to {output} ({len(frame):,} rows)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
