#!/usr/bin/env python3
"""Download a public daily QQQ/VIX/IRX adjusted-close file and optionally merge VXN."""

from __future__ import annotations

import argparse
from io import StringIO
from pathlib import Path

import pandas as pd
import requests

DEFAULT_MARKETDATA_URL = (
    "https://raw.githubusercontent.com/manisahni/marketdata/main/daily_adjclose.csv"
)
FRED_VXN_URL = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=VXNCLS"


def download_text(url: str, timeout: int = 60) -> str:
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    return response.text


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/daily_adjclose.csv")
    parser.add_argument("--url", default=DEFAULT_MARKETDATA_URL)
    parser.add_argument(
        "--with-vxn",
        action="store_true",
        help="Merge the FRED VXNCLS series into a ^VXN column.",
    )
    args = parser.parse_args()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)

    market = pd.read_csv(StringIO(download_text(args.url)))
    required = {"Date", "QQQ", "^IRX", "^VIX"}
    missing = required - set(market.columns)
    if missing:
        raise SystemExit(f"Downloaded file is missing required columns: {sorted(missing)}")

    if args.with_vxn:
        vxn = pd.read_csv(StringIO(download_text(FRED_VXN_URL)))
        date_column = "DATE" if "DATE" in vxn.columns else vxn.columns[0]
        value_column = "VXNCLS" if "VXNCLS" in vxn.columns else vxn.columns[-1]
        vxn = vxn.rename(columns={date_column: "Date", value_column: "^VXN"})[["Date", "^VXN"]]
        vxn["^VXN"] = pd.to_numeric(vxn["^VXN"], errors="coerce")
        market = market.merge(vxn, on="Date", how="left")

    market.to_csv(output, index=False)
    print(f"Saved {len(market):,} rows to {output}")
    print(f"Date range: {market['Date'].iloc[0]} through {market['Date'].iloc[-1]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
