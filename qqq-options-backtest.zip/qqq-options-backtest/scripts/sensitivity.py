#!/usr/bin/env python3
"""Run a compact sensitivity grid for the model-based backtest."""

from __future__ import annotations

import argparse
import copy
import itertools
from pathlib import Path

import pandas as pd

from qqq_options_backtest.config import load_config
from qqq_options_backtest.data import load_market_data
from qqq_options_backtest.engine import run_backtest
from qqq_options_backtest.providers import BlackScholesProvider


def parse_float_list(value: str) -> list[float]:
    return [float(item.strip()) for item in value.split(",") if item.strip()]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config/default.yaml")
    parser.add_argument("--market-data", default=None)
    parser.add_argument("--years", type=int, default=20)
    parser.add_argument("--mode", choices=["daily_ladder", "weekly_single"], default="daily_ladder")
    parser.add_argument("--moneyness", default="0.00,0.01,0.02")
    parser.add_argument("--vix-multipliers", default="1.00,1.15,1.30")
    parser.add_argument("--half-spreads", default="0.01,0.025,0.05")
    parser.add_argument("--output", default="outputs/sensitivity.csv")
    args = parser.parse_args()

    base = load_config(args.config)
    if args.market_data:
        base.data.market_data_path = args.market_data
    base.data.years = args.years
    base.strategy.mode = args.mode
    base.data.quote_mode = "model"

    rows = []
    grid = itertools.product(
        parse_float_list(args.moneyness),
        parse_float_list(args.vix_multipliers),
        parse_float_list(args.half_spreads),
    )
    for moneyness, vix_multiplier, half_spread in grid:
        config = copy.deepcopy(base)
        config.strategy.moneyness = moneyness
        config.model.vix_multiplier = vix_multiplier
        config.execution.model_half_spread_pct = half_spread
        market = load_market_data(config.data.market_data_path, config)
        result = run_backtest(market, BlackScholesProvider(config), config)
        rows.append(
            {
                "moneyness": moneyness,
                "vix_multiplier": vix_multiplier,
                "half_spread_pct": half_spread,
                **result.summary,
            }
        )
        print(
            f"m={moneyness:.1%}, volx={vix_multiplier:.2f}, spread={half_spread:.1%}: "
            f"CAGR={result.summary['cagr']:.2%}, MDD={result.summary['max_drawdown']:.2%}"
        )

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)
    print(f"Saved {len(rows)} scenarios to {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
