# Validation record

Validated on 2026-10-27.

- 10 automated tests passed.
- Black-Scholes pricing matches a standard reference value.
- Daily-ladder exposure never exceeds five simultaneous lots in the test fixture.
- Weekly mode enters materially less often and holds no more than one lot.
- Total return uses the original initial capital, including first-entry spread and commission drag.
- Historical quote parsing and 25-30 DTE/nearest-strike selection were tested.
- A deterministic 20-year synthetic dataset completed end to end and produced every report artifact.
- The bundled demo report is explicitly labeled synthetic and must not be interpreted as historical performance.

The environment used for packaging did not permit external downloads into the execution sandbox. Therefore no historical QQQ option-return numbers are asserted in the bundled validation report. Run the downloader in a networked Python environment for the model approximation, or supply historical QQQ quotes for exact-quote mode.
