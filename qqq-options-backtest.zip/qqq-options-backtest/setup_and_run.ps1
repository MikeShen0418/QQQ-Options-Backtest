$ErrorActionPreference = "Stop"

$Python = "py"
& $Python -m venv .venv
$VenvPython = Join-Path $PSScriptRoot ".venv\Scripts\python.exe"

& $VenvPython -m pip install --upgrade pip
& $VenvPython -m pip install -r requirements.txt
& $VenvPython -m pip install -e .
& $VenvPython scripts/download_marketdata.py --with-vxn
& $VenvPython scripts/run_all.py --market-data data/daily_adjclose.csv --quote-mode model --output-root outputs

Write-Host "Finished. Open outputs\comparison_summary.csv and the report.html file inside each run folder."
