# QQQ 25-30 DTE Call-Roll Backtest

A reusable Python project for testing a strategy that buys QQQ call options with 25-30 calendar days to expiration, holds each lot for one trading week, and rolls continuously.

The project implements both reasonable interpretations of the sizing rule:

1. **`daily_ladder`** — invest about 1% of current portfolio equity each trading day, hold each lot for five trading sessions, and keep at most five overlapping lots. This uses up to roughly 5% of the portfolio as option premium.
2. **`weekly_single`** — invest about 1% once each week, hold for five trading sessions, then replace it. The 5% sleeve remains a hard cap but is normally underused.

The default call is **at-the-money**. Strike selection is configurable through `moneyness`; `0.02` means a strike approximately 2% above spot.

## What the backtest reports

For the total portfolio:

- Total return and CAGR
- Annualized volatility and zero-risk-rate Sharpe ratio
- Maximum drawdown, peak date, and trough date
- Calmar ratio, best day, and worst day
- Maximum number of simultaneous positions and maximum premium reserved
- QQQ buy-and-hold comparison

For the option trades:

- Trade count, win rate, average/median/best/worst premium return
- Total option P&L, premium turnover, commissions, and profit factor
- Longest losing streak
- Number and percentage of “wipeout” trades
- Longest consecutive wipeout streak
- Number of wipeout-streak episodes of length two or more
- `wipeout_streaks.csv` and `loss_streaks.csv` with the dates and trade IDs for every streak

A **wipeout** defaults to a single option lot losing at least 90% of its premium, including commissions. It does **not** mean the entire portfolio went to zero. Change the threshold in `config/default.yaml`.

## Two data modes

### 1. Historical-quote mode — preferred for real conclusions

This mode uses supplied historical QQQ option bid/ask quotes. It selects a call whose actual DTE is between 25 and 30 and whose strike is closest to the configured moneyness. It buys at the ask and sells at the bid.

Required normalized quote columns:

```text
quote_date, expiration, option_type, strike, bid, ask
```

Optional columns:

```text
mid, underlying, symbol, volume, open_interest, delta
```

A schema example is in `examples/historical_option_quotes_schema.csv`.

For a large OPRA file, prefilter it to QQQ calls and the relevant date range before loading. Full tick-level OPRA history is too large for an ordinary in-memory CSV workflow.

### 2. Model mode — useful for research and sensitivity testing

This mode constructs option marks with Black-Scholes and daily QQQ, interest-rate, and volatility-proxy data. The default public-data path uses:

- QQQ adjusted daily closes
- 13-week T-bill rate (`^IRX`)
- VIX multiplied by a configurable factor as a rough Nasdaq volatility proxy

A VXN series can be merged and selected with `iv_mode: vxn`. VXN is still a Nasdaq-100 volatility proxy, not an exact QQQ option surface.

Model mode is **not** the same as a historical-option-quote backtest. It cannot reproduce skew, term structure, discrete listed strikes, early-exercise value, quote staleness, or crisis-period bid/ask behavior. Use the sensitivity script rather than relying on one set of model assumptions.

## Installation

Python 3.10 or later is recommended.

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

python -m pip install -r requirements.txt
python -m pip install -e .
```

Run the tests:

```bash
python -m pytest
```

On Windows, `setup_and_run.ps1` performs the environment setup, downloads the public model inputs, and runs all four 10-year/20-year scenarios.

## Download public market data

```bash
python scripts/download_marketdata.py --with-vxn
```

This writes `data/daily_adjclose.csv`. Without `--with-vxn`, the default configuration uses scaled VIX. With VXN merged, change the YAML to:

```yaml
model:
  iv_mode: vxn
```

The downloader only provides the market inputs for the **modeled** option prices. It does not download historical QQQ option chains.

## Run one backtest

Twenty-year daily ladder, model mode:

```bash
qqq-backtest \
  --config config/default.yaml \
  --market-data data/daily_adjclose.csv \
  --years 20 \
  --mode daily_ladder \
  --output outputs/20y_daily_ladder_model
```

Ten-year weekly single-lot version:

```bash
qqq-backtest \
  --market-data data/daily_adjclose.csv \
  --years 10 \
  --mode weekly_single \
  --output outputs/10y_weekly_single_model
```

Historical-quote mode:

```bash
qqq-backtest \
  --market-data data/daily_adjclose.csv \
  --quote-mode historical \
  --option-quotes data/qqq_option_quotes.csv \
  --years 20 \
  --mode daily_ladder \
  --output outputs/20y_daily_ladder_exact
```

## Run all four requested combinations

```bash
python scripts/run_all.py \
  --market-data data/daily_adjclose.csv \
  --quote-mode model \
  --output-root outputs
```

This runs:

- 10-year daily ladder
- 10-year weekly single
- 20-year daily ladder
- 20-year weekly single

The combined results are written to `outputs/comparison_summary.csv` and `outputs/comparison_summary.json`.

## Sensitivity analysis

The model result can move materially with strike choice, implied-volatility assumptions, and execution spread. Run the included grid:

```bash
python scripts/sensitivity.py \
  --market-data data/daily_adjclose.csv \
  --years 20 \
  --mode daily_ladder \
  --moneyness 0.00,0.01,0.02 \
  --vix-multipliers 1.00,1.15,1.30 \
  --half-spreads 0.01,0.025,0.05 \
  --output outputs/sensitivity.csv
```

## Output files

Each run creates:

```text
report.html
summary.json
summary.csv
equity_curve.csv
trades.csv
wipeout_streaks.csv
loss_streaks.csv
equity_curve.png
drawdown.png
trade_return_histogram.png
```

Open `report.html` for the easiest review.

## Important assumptions

- Entry and exit happen at the daily close; the system has no intraday information.
- Each lot is held for five trading sessions, not five calendar days.
- The daily ladder exits the oldest lot before entering its replacement, so it has at most five active lots.
- Position sizing uses current equity. Premium committed to active trades is capped by original entry cost, not current option market value.
- The unallocated portion of the portfolio earns the supplied short-term rate by default. Set `earn_cash_interest: false` to isolate option P&L from cash yield.
- Fractional contracts are enabled by default so a 1% sizing rule is testable at a $100,000 starting balance. Use `--whole-contracts` for executable contract counts; small accounts may skip many entries.
- Model mode applies a configurable synthetic half-spread and commissions. Historical mode uses supplied ask prices for entry and bid prices for exit.
- The public QQQ series is adjusted close. Therefore the default model dividend yield is zero. For unadjusted spot data, set an appropriate dividend yield.
- Taxes, assignment, brokerage-specific fees, market impact, and portfolio margin are excluded.
- Results are research outputs, not investment advice.

## Project layout

```text
config/default.yaml                 Strategy and model assumptions
src/qqq_options_backtest/           Backtest package
scripts/download_marketdata.py      Public market-data downloader
scripts/run_all.py                  10y/20y and daily/weekly batch run
scripts/sensitivity.py              Model-assumption grid
scripts/generate_demo_data.py       Synthetic plumbing test only
examples/                            Quote schema example
notebooks/                           Interactive workflow
outputs/demo/                        Synthetic validation report
 tests/                              Automated tests
```

The synthetic demo output exists only to prove that the software runs end to end. Do not interpret its returns as historical QQQ strategy performance.
